require 'plasma_applet'

module RubyTestApplet
  class Main < PlasmaScripting::Applet

    slots :addText

    def init
      set_minimum_size 150, 150

      @layout = Qt::GraphicsLinearLayout.new Qt::Vertical, self
      self.layout = @layout

      @label = Plasma::Label.new self
      @label.text = 'This plasmoid will copy the text you enter below to the clipboard.'
      @layout.add_item @label

      @line_edit = Plasma::LineEdit.new self

      begin
        @line_edit.clear_button_shown = true # not supported in early plasma versions
      rescue
        nil # but that doesn't matter'
      end

      @layout.add_item @line_edit

      @button = Plasma::PushButton.new self
      @button.text = 'Copy to clipboard'
      @layout.add_item @button

      Qt::Object.connect( @button, SIGNAL(:clicked), self, SLOT(:addText) )
      Qt::Object.connect( @line_edit, SIGNAL(:returnPressed), self, SLOT(:addText) )
    end

    def addText
      Qt::Application.clipboard.text = @line_edit.text
      @line_edit.text = ""
    end

  end
end

# kate: remove_trailing_space on; replace-trailing-space-save on; indent-width 2; indent-mode ruby;