# kate: remove-trailing-space on; replace-trailing-space-save on; indent-width 2; indent-mode ruby; syntax ruby; replace-tabs on; replace-tabs-save on; space-indent on;
require 'plasma_applet'

# the dictonary replaces the ruby hash as we need an ordered hash. only ruby 1.9 uses ordered one.
# when ruby1.9 is the default version, we can switch back to native ruby hash
require 'dictionary'

module RubyStocks
  class Main < PlasmaScripting::DataEngine

    # the url needs to be extended by the stock ID at the end of the string
    # format code: http://brusdeylins.info/projects/yahoo-finance-api/
    DATA = Dictionary[
      "j1" => ["market capitalization", Float],
      "p2" => ["percent change", String],
      "s0" => ["symbol",String],
      "d1" => ["last trade date", Qt::Date],
      "t1" => ["last trade time", Qt::Time],
      "c1" => ["change", Float],
      "o0" => ["open", Float],
      "h0" => ["days high", Float],
      "g0" => ["days low", Float],
      "v0" => ["volume", Float],
      "a2" => ["average daily volume", Float],
      "l1" => ["last trade", Float],
      "c4" => ["currency", String]
    ]

    SOURCE_URL = "http://download.finance.yahoo.com/d/quotes.csv?f=#{DATA.keys.join}&e=.csv&s="

    def initialize parent, args = nil
      super parent

      # don't update faster than once a minute
      setMinimumPollingInterval 60000
      # dafault update rate is 10 minutes
      setPollingInterval 600000

    end

    def updateSourceEvent source
      request_url = SOURCE_URL + Qt::Url::toPercentEncoding(source).data.strip
      job = KIO::storedGet KDE::Url.new(request_url), KIO::NoReload, KIO::HideProgressInfo
      job.connect( SIGNAL( 'result( KJob* )' ) ) do |aJob|
        parseCSVLine source, aJob.data
      end

      return false
    end

    def parseCSVLine source, dataByteArray
      $stderr.puts "ruby-stocks plasma dataengine: retrieved data: " + dataByteArray.data
      dataArray = dataByteArray.data.strip.split ","
      if dataArray.size >= DATA.size
        DATA.values.each do |aValue|
          data =  dataArray.shift
          unless data =~ %r{N/A}
            if aValue[1] == Float
                data.gsub! /B$/, "E6"
                data.gsub! /M$/, "E3"
                setData source, aValue[0], data.to_f unless data == "N/A"
            elsif aValue[1] == String
              data = data[1..-2]
              setData source, aValue[0], data unless data.empty?
            elsif aValue[1] == Qt::Time
              setData source, aValue[0], Qt::Time.fromString(data, '"h:mmap"')
            elsif aValue[1] == Qt::Date
              setData source, aValue[0], Qt::Date.fromString(data, '"M/d/yyyy"')
            end
          end
        end
      end
    end

    alias sourceRequestEvent updateSourceEvent

  end

end